"""
孟加拉商业情报日报系统 - RSS采集器
支持多源并发采集、去重、内容提取
"""
import json
import hashlib
import time
import re
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlparse
import requests
import feedparser
from bs4 import BeautifulSoup


class RSSCrawler:
    def __init__(self, sources_path="config/sources.json", max_workers=10, timeout=15):
        self.sources = self._load_sources(sources_path)
        self.max_workers = max_workers
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
        })
        self.seen_urls = set()
        self.seen_hashes = set()

    def _load_sources(self, path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)["sources"]

    def _fetch_feed(self, source):
        """获取单个RSS源"""
        try:
            resp = self.session.get(source["url"], timeout=self.timeout)
            resp.raise_for_status()
            feed = feedparser.parse(resp.content)
            entries = []
            for entry in feed.entries[:15]:  # 每个源最多15条
                item = self._parse_entry(entry, source)
                if item and self._is_new(item):
                    entries.append(item)
            return {
                "source": source["name"],
                "success": True,
                "count": len(entries),
                "items": entries,
                "error": None
            }
        except Exception as e:
            return {
                "source": source["name"],
                "success": False,
                "count": 0,
                "items": [],
                "error": str(e)
            }

    def _parse_entry(self, entry, source):
        """解析RSS条目"""
        try:
            title = entry.get("title", "").strip()
            link = entry.get("link", "").strip()
            summary = entry.get("summary", entry.get("description", "")).strip()
            published = entry.get("published", entry.get("updated", ""))

            # 清理HTML标签
            summary = BeautifulSoup(summary, "html.parser").get_text(separator=" ", strip=True)

            if not title or not link:
                return None

            # 生成唯一ID
            item_id = hashlib.md5(f"{title}:{link}".encode()).hexdigest()[:16]

            # 解析日期
            pub_date = self._parse_date(published)

            # 只采集最近3天的新闻
            if pub_date and pub_date < datetime.now() - timedelta(days=3):
                return None

            return {
                "id": item_id,
                "title": title,
                "link": link,
                "summary": summary[:500],
                "source_name": source["name"],
                "source_lang": source.get("lang", "en"),
                "source_priority": source.get("priority", 2),
                "source_category": source.get("category", "general"),
                "published": pub_date.isoformat() if pub_date else datetime.now().isoformat(),
                "collected_at": datetime.now().isoformat(),
            }
        except Exception:
            return None

    def _parse_date(self, date_str):
        """解析多种日期格式"""
        if not date_str:
            return datetime.now()
        formats = [
            "%a, %d %b %Y %H:%M:%S %z",
            "%a, %d %b %Y %H:%M:%S %Z",
            "%Y-%m-%dT%H:%M:%S%z",
            "%Y-%m-%dT%H:%M:%SZ",
            "%Y-%m-%d %H:%M:%S",
            "%d %b %Y %H:%M:%S",
            "%a %d %b %Y %I:%M %p",
        ]
        for fmt in formats:
            try:
                return datetime.strptime(date_str, fmt)
            except ValueError:
                continue
        try:
            # feedparser可能已解析
            from email.utils import parsedate_to_datetime
            return parsedate_to_datetime(date_str)
        except Exception:
            return datetime.now()

    def _is_new(self, item):
        """检查是否已采集过"""
        if item["link"] in self.seen_urls:
            return False
        content_hash = hashlib.md5(item["title"].encode()).hexdigest()[:12]
        if content_hash in self.seen_hashes:
            return False
        self.seen_urls.add(item["link"])
        self.seen_hashes.add(content_hash)
        return True

    def crawl(self, target_count=50):
        """并发采集所有源"""
        print(f"[Crawler] 开始采集 {len(self.sources)} 个RSS源...")
        results = []
        all_items = []

        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_source = {executor.submit(self._fetch_feed, s): s for s in self.sources}
            for future in as_completed(future_to_source):
                result = future.result()
                results.append(result)
                if result["success"]:
                    all_items.extend(result["items"])
                print(f"  {'✓' if result['success'] else '✗'} {result['source']}: {result['count']}条")

        # 按优先级和时间排序
        all_items.sort(key=lambda x: (x["source_priority"], x["published"]), reverse=True)

        # 去重后取目标数量
        final_items = []
        seen_titles = set()
        for item in all_items:
            # 基于标题相似度去重
            title_key = re.sub(r'[^\w]', '', item["title"].lower())[:30]
            if title_key not in seen_titles:
                seen_titles.add(title_key)
                final_items.append(item)
            if len(final_items) >= target_count:
                break

        # 统计
        success_count = sum(1 for r in results if r["success"])
        print(f"[Crawler] 采集完成: {success_count}/{len(self.sources)} 源成功, 共 {len(final_items)} 条新闻")

        return {
            "items": final_items,
            "stats": {
                "total_sources": len(self.sources),
                "success_sources": success_count,
                "total_items": len(all_items),
                "final_items": len(final_items),
                "timestamp": datetime.now().isoformat()
            }
        }


if __name__ == "__main__":
    crawler = RSSCrawler()
    result = crawler.crawl(target_count=50)
    print(f"\n采集统计: {result['stats']}")
