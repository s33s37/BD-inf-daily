"""
孟加拉商业情报日报系统 - AI分析器
使用OpenAI API进行智能分析
支持产业分类、实体提取、影响判断、风险标记
"""
import json
import os
import re
from datetime import datetime
from typing import List, Dict, Any
import openai


class IntelligenceAnalyzer:
    def __init__(self, industries_path="config/industries.json"):
        self.industries = self._load_industries(industries_path)
        self.api_key = os.environ.get("OPENAI_API_KEY") or os.environ.get("DEEPSEEK_API_KEY")
        if not self.api_key:
            raise ValueError("请设置 OPENAI_API_KEY 或 DEEPSEEK_API_KEY 环境变量")

        # 自动检测API提供商
        if os.environ.get("DEEPSEEK_API_KEY"):
            self.client = openai.OpenAI(api_key=self.api_key, base_url="https://api.deepseek.com/v1")
            self.model = "deepseek-chat"
        else:
            self.client = openai.OpenAI(api_key=self.api_key)
            self.model = "gpt-4o-mini"  # 成本较低，适合批量处理

    def _load_industries(self, path):
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data

    def _build_system_prompt(self):
        """构建系统提示词"""
        industries_text = "\n".join([
            f"- {ind['id']}: {ind['name']} (关键词: {', '.join(ind['keywords'][:8])})"
            for ind in self.industries["industries"]
        ])

        types_text = "\n".join([
            f"- {t['id']}: {t['name']} (关键词: {', '.join(t['keywords'][:6])})"
            for t in self.industries["intelligence_types"]
        ])

        return f"""你是一位专业的孟加拉国商业情报分析师，服务于中国政策制定者、智库学者和跨境电商从业者。

你的任务是对孟加拉国商业新闻进行深度分析，输出结构化的情报报告。

## 产业分类（22个）
{industries_text}

## 情报类型（7个）
{types_text}

## 分析要求
1. 产业分类：基于新闻内容，判断最相关的1-3个产业
2. 情报类型：判断新闻属于哪种类型
3. 实体提取：提取关键公司、机构、人物、项目、金额、地点
4. 中文摘要：用简洁专业的中文总结新闻要点（100-150字）
5. 影响判断：正面(positive)/中性(neutral)/负面(negative)，并说明理由
6. 重要性：高(high)/中(medium)/低(low)
7. 风险标记：如果涉及风险，标记具体风险类型
8. 判断依据：列出支持判断的关键证据

## 输出格式（严格JSON）
{{
    "industries": ["产业ID1", "产业ID2"],
    "intelligence_type": "类型ID",
    "entities": {{
        "companies": ["公司名"],
        "organizations": ["机构名"],
        "people": ["人名"],
        "projects": ["项目名"],
        "amounts": ["金额"],
        "locations": ["地点"]
    }},
    "chinese_summary": "中文摘要",
    "impact": "positive/neutral/negative",
    "impact_reason": "影响判断理由",
    "importance": "high/medium/low",
    "risk_tags": ["风险类型1", "风险类型2"],
    "risk_level": "high/medium/low/none",
    "evidence": ["证据1", "证据2"],
    "confidence": 0.85
}}

注意：
- 如果新闻涉及中国（China/Chinese/Beijing/一带一路/BRI），请务必在摘要中强调
- 如果涉及政策变化，请标注政策影响范围
- 金额统一转换为美元或标注原币种
- 摘要必须通顺、专业、信息完整"""

    def analyze_item(self, item: Dict[str, Any]) -> Dict[str, Any]:
        """分析单条新闻"""
        try:
            prompt = f"""请分析以下孟加拉国商业新闻：

标题：{item['title']}
来源：{item['source_name']}
摘要：{item['summary']}
链接：{item['link']}

请严格按照系统提示的JSON格式输出分析结果。"""

            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": self._build_system_prompt()},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,
                max_tokens=1500,
                response_format={"type": "json_object"}
            )

            result_text = response.choices[0].message.content
            analysis = json.loads(result_text)

            # 合并原始数据
            analysis["original"] = item
            analysis["analysis_time"] = datetime.now().isoformat()
            analysis["model"] = self.model

            return analysis

        except Exception as e:
            # 失败时返回基础分析
            return {
                "industries": ["others"],
                "intelligence_type": "general",
                "entities": {"companies": [], "organizations": [], "people": [], "projects": [], "amounts": [], "locations": []},
                "chinese_summary": f"[分析失败] {item['title']}",
                "impact": "neutral",
                "impact_reason": f"分析出错: {str(e)}",
                "importance": "low",
                "risk_tags": [],
                "risk_level": "none",
                "evidence": [],
                "confidence": 0.0,
                "original": item,
                "analysis_time": datetime.now().isoformat(),
                "error": str(e)
            }

    def analyze_batch(self, items: List[Dict[str, Any]], batch_size=5) -> List[Dict[str, Any]]:
        """批量分析新闻"""
        print(f"[Analyzer] 开始分析 {len(items)} 条新闻...")
        results = []

        for i in range(0, len(items), batch_size):
            batch = items[i:i+batch_size]
            for item in batch:
                result = self.analyze_item(item)
                results.append(result)
                status = "✓" if "error" not in result else "✗"
                print(f"  {status} [{result.get('industries', ['?'])[0]}] {item['title'][:50]}...")
            # 短暂休息避免API限流
            import time
            time.sleep(0.5)

        print(f"[Analyzer] 分析完成: {len(results)} 条")
        return results

    def get_stats(self, analyses: List[Dict[str, Any]]) -> Dict[str, Any]:
        """生成分析统计"""
        stats = {
            "total": len(analyses),
            "by_industry": {},
            "by_type": {},
            "by_impact": {"positive": 0, "neutral": 0, "negative": 0},
            "by_importance": {"high": 0, "medium": 0, "low": 0},
            "risk_count": 0,
            "policy_count": 0,
            "avg_confidence": 0.0,
            "china_related": 0
        }

        confidences = []
        for a in analyses:
            # 产业统计
            for ind in a.get("industries", ["others"]):
                stats["by_industry"][ind] = stats["by_industry"].get(ind, 0) + 1

            # 类型统计
            t = a.get("intelligence_type", "general")
            stats["by_type"][t] = stats["by_type"].get(t, 0) + 1

            # 影响统计
            impact = a.get("impact", "neutral")
            stats["by_impact"][impact] = stats["by_impact"].get(impact, 0) + 1

            # 重要性统计
            imp = a.get("importance", "low")
            stats["by_importance"][imp] = stats["by_importance"].get(imp, 0) + 1

            # 风险统计
            if a.get("risk_level") in ["high", "medium"]:
                stats["risk_count"] += 1

            # 政策统计
            if t == "policy":
                stats["policy_count"] += 1

            # 置信度
            conf = a.get("confidence", 0)
            if conf > 0:
                confidences.append(conf)

            # 中国相关
            summary = a.get("chinese_summary", "")
            if any(kw in summary.lower() for kw in ["中国", "中方", "北京", "上海", "深圳", "一带一路", "bri", "china", "chinese"]):
                stats["china_related"] += 1

        if confidences:
            stats["avg_confidence"] = round(sum(confidences) / len(confidences), 2)

        return stats


if __name__ == "__main__":
    analyzer = IntelligenceAnalyzer()
    test_item = {
        "title": "Bangladesh garment exports rise 15% in Q1",
        "source_name": "The Daily Star",
        "summary": "Bangladesh's readymade garment exports increased by 15% in the first quarter...",
        "link": "https://example.com/news/1"
    }
    result = analyzer.analyze_item(test_item)
    print(json.dumps(result, ensure_ascii=False, indent=2))
