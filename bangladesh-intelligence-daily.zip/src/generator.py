
"""
孟加拉商业情报日报系统 - 报告生成器
生成带颜色标签的移动端友好HTML日报
"""
import json
import os
from datetime import datetime
from typing import List, Dict, Any


class ReportGenerator:
    def __init__(self, industries_path="config/industries.json"):
        with open(industries_path, "r", encoding="utf-8") as f:
            self.industries_data = json.load(f)
        self.industry_map = {ind["id"]: ind for ind in self.industries_data["industries"]}
        self.type_map = {t["id"]: t for t in self.industries_data["intelligence_types"]}

    def _get_industry_name(self, ind_id):
        return self.industry_map.get(ind_id, {}).get("name", ind_id)

    def _get_type_name(self, type_id):
        return self.type_map.get(type_id, {}).get("name", type_id)

    def _get_industry_color(self, ind_id):
        colors = {
            "garment": "#e74c3c", "infrastructure": "#3498db", "energy": "#f39c12",
            "solar": "#f1c40f", "e2w": "#2ecc71", "ev": "#27ae60",
            "pharma": "#9b59b6", "ict_ecommerce": "#1abc9c", "jute": "#d4a017",
            "leather": "#8b4513", "shipbreaking": "#34495e", "fisheries": "#16a085",
            "agro": "#e67e22", "ceramics": "#c0392b", "furniture": "#7f8c8d",
            "light_mfg": "#2c3e50", "shipbuilding": "#2980b9", "medical": "#8e44ad",
            "plastics": "#e91e63", "appliances": "#00bcd4", "digital_economy": "#3f51b5",
            "others": "#95a5a6"
        }
        return colors.get(ind_id, "#95a5a6")

    def _get_impact_badge(self, impact):
        badges = {
            "positive": ('<span class="badge badge-positive">正面</span>', "正面信号"),
            "neutral": ('<span class="badge badge-neutral">中性</span>', "中性观察"),
            "negative": ('<span class="badge badge-negative">负面</span>', "风险预警")
        }
        return badges.get(impact, badges["neutral"])

    def _get_importance_badge(self, importance):
        badges = {
            "high": '<span class="badge badge-high">高</span>',
            "medium": '<span class="badge badge-medium">中</span>',
            "low": '<span class="badge badge-low">低</span>'
        }
        return badges.get(importance, badges["low"])

    def _get_risk_badge(self, risk_level):
        if risk_level in ["high", "medium"]:
            return '<span class="badge badge-risk">风险</span>'
        return ''

    def generate_html(self, analyses, stats, output_dir="docs"):
        """生成完整HTML报告"""
        os.makedirs(output_dir, exist_ok=True)

        date_str = datetime.now().strftime("%Y年%m月%d日")
        date_iso = datetime.now().strftime("%Y-%m-%d")

        # 按产业分组
        by_industry = {}
        for a in analyses:
            for ind in a.get("industries", ["others"]):
                if ind not in by_industry:
                    by_industry[ind] = []
                by_industry[ind].append(a)

        # 风险预警区
        risk_items = [a for a in analyses if a.get("risk_level") in ["high", "medium"]]
        risk_items.sort(key=lambda x: 0 if x.get("risk_level") == "high" else 1)

        # 政策雷达区
        policy_items = [a for a in analyses if a.get("intelligence_type") == "policy"]

        # 正面信号区
        positive_items = [a for a in analyses if a.get("impact") == "positive"]

        # 生成HTML
        html = self._build_full_html(date_str, date_iso, stats, risk_items, policy_items, positive_items, by_industry, analyses)

        output_path = os.path.join(output_dir, "index.html")
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)

        # 同时生成历史归档
        archive_path = os.path.join(output_dir, f"report_{date_iso}.html")
        with open(archive_path, "w", encoding="utf-8") as f:
            f.write(html)

        print(f"[Generator] 报告已生成: {output_path}")
        return output_path

    def _build_full_html(self, date_str, date_iso, stats, risk_items, policy_items, positive_items, by_industry, all_items):
        """构建完整HTML"""

        # 统计面板
        stats_panel = """
        <div class="stats-panel">
            <div class="stat-card">
                <div class="stat-number">""" + str(stats['total']) + """</div>
                <div class="stat-label">采集情报</div>
            </div>
            <div class="stat-card stat-risk">
                <div class="stat-number">""" + str(stats['risk_count']) + """</div>
                <div class="stat-label">风险预警</div>
            </div>
            <div class="stat-card stat-policy">
                <div class="stat-number">""" + str(stats['policy_count']) + """</div>
                <div class="stat-label">政策动态</div>
            </div>
            <div class="stat-card stat-positive">
                <div class="stat-number">""" + str(stats['by_impact'].get('positive', 0)) + """</div>
                <div class="stat-label">正面信号</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">""" + str(stats.get('china_related', 0)) + """</div>
                <div class="stat-label">涉华情报</div>
            </div>
        </div>
        """

        # 各区域
        risk_section = self._build_section("风险预警区", "risk-section", risk_items, max_items=10, empty_msg="今日无重大风险预警")
        policy_section = self._build_section("政策雷达区", "policy-section", policy_items, max_items=10, empty_msg="今日无重大政策动态")
        positive_section = self._build_section("正面信号区", "positive-section", positive_items, max_items=8, empty_msg="今日无重大正面信号")

        # 分产业动态卡片
        industry_sections = ""
        priority_order = ["garment", "infrastructure", "energy", "solar", "e2w", "ev", 
                         "pharma", "ict_ecommerce", "digital_economy", "agro", "jute", 
                         "leather", "shipbreaking", "fisheries", "ceramics", "furniture",
                         "light_mfg", "shipbuilding", "medical", "plastics", "appliances", "others"]

        for ind_id in priority_order:
            if ind_id in by_industry:
                items = by_industry[ind_id]
                ind_name = self._get_industry_name(ind_id)
                ind_color = self._get_industry_color(ind_id)
                industry_sections += self._build_industry_section(ind_id, ind_name, ind_color, items)

        # CSS样式（使用字符串拼接避免f-string冲突）
        css = """
        :root { --primary: #1a5276; --danger: #c0392b; --warning: #e67e22; --success: #27ae60; --info: #3498db; --bg: #f8f9fa; --card-bg: #ffffff; --text: #2c3e50; --text-light: #7f8c8d; --border: #e0e0e0; }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans SC", "PingFang SC", "Microsoft YaHei", sans-serif; background: var(--bg); color: var(--text); line-height: 1.6; -webkit-font-smoothing: antialiased; }
        .container { max-width: 800px; margin: 0 auto; padding: 0 16px; }
        .header { background: linear-gradient(135deg, #1a5276 0%, #2c3e50 100%); color: white; padding: 24px 16px; text-align: center; position: sticky; top: 0; z-index: 100; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .header h1 { font-size: 1.4rem; font-weight: 700; margin-bottom: 4px; }
        .header .subtitle { font-size: 0.85rem; opacity: 0.9; }
        .header .date { font-size: 0.75rem; opacity: 0.8; margin-top: 4px; }
        .header .badge-live { display: inline-block; background: #e74c3c; color: white; font-size: 0.65rem; padding: 2px 8px; border-radius: 12px; margin-left: 8px; animation: pulse 2s infinite; }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.6; } }
        .stats-panel { display: grid; grid-template-columns: repeat(5, 1fr); gap: 8px; padding: 16px; background: white; margin: 16px 0; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
        .stat-card { text-align: center; padding: 12px 4px; border-radius: 8px; background: #f8f9fa; }
        .stat-card .stat-number { font-size: 1.5rem; font-weight: 700; color: var(--primary); }
        .stat-card .stat-label { font-size: 0.65rem; color: var(--text-light); margin-top: 2px; }
        .stat-risk .stat-number { color: var(--danger); }
        .stat-policy .stat-number { color: var(--info); }
        .stat-positive .stat-number { color: var(--success); }
        .section { background: white; border-radius: 12px; margin: 16px 0; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
        .section-header { padding: 14px 16px; font-size: 1rem; font-weight: 700; display: flex; align-items: center; gap: 8px; }
        .risk-section .section-header { background: #fdf2f2; color: var(--danger); border-left: 4px solid var(--danger); }
        .policy-section .section-header { background: #ebf5fb; color: var(--info); border-left: 4px solid var(--info); }
        .positive-section .section-header { background: #eafaf1; color: var(--success); border-left: 4px solid var(--success); }
        .industry-section .section-header { background: #f8f9fa; border-left: 4px solid; }
        .section-content { padding: 0; }
        .empty-msg { padding: 24px; text-align: center; color: var(--text-light); font-size: 0.9rem; }
        .intel-card { padding: 14px 16px; border-bottom: 1px solid var(--border); transition: background 0.2s; }
        .intel-card:last-child { border-bottom: none; }
        .intel-card:active { background: #f8f9fa; }
        .card-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px; gap: 8px; }
        .card-title { font-size: 0.95rem; font-weight: 600; color: var(--text); line-height: 1.4; flex: 1; }
        .card-badges { display: flex; gap: 4px; flex-wrap: wrap; }
        .badge { display: inline-block; font-size: 0.65rem; padding: 2px 8px; border-radius: 4px; font-weight: 600; white-space: nowrap; }
        .badge-positive { background: #d4edda; color: #155724; }
        .badge-neutral { background: #fff3cd; color: #856404; }
        .badge-negative { background: #f8d7da; color: #721c24; }
        .badge-high { background: #f8d7da; color: #721c24; }
        .badge-medium { background: #fff3cd; color: #856404; }
        .badge-low { background: #d1ecf1; color: #0c5460; }
        .badge-risk { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .badge-industry { background: #e9ecef; color: #495057; }
        .badge-type { background: #e3f2fd; color: #1565c0; }
        .badge-china { background: #fde7e7; color: #c0392b; }
        .card-summary { font-size: 0.85rem; color: var(--text); line-height: 1.6; margin-bottom: 8px; }
        .card-summary .china-highlight { color: #c0392b; font-weight: 600; }
        .card-meta { display: flex; justify-content: space-between; align-items: center; font-size: 0.75rem; color: var(--text-light); flex-wrap: wrap; gap: 4px; }
        .card-meta-left { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
        .card-source { font-weight: 500; }
        .card-link { color: var(--info); text-decoration: none; font-weight: 500; }
        .card-link:hover { text-decoration: underline; }
        .card-entities { margin-top: 8px; padding-top: 8px; border-top: 1px dashed var(--border); font-size: 0.75rem; color: var(--text-light); }
        .entity-tag { display: inline-block; background: #f1f3f4; padding: 1px 6px; border-radius: 3px; margin: 2px 4px 2px 0; font-size: 0.7rem; }
        .card-evidence { margin-top: 6px; font-size: 0.75rem; color: var(--text-light); font-style: italic; }
        .footer { text-align: center; padding: 24px 16px; font-size: 0.75rem; color: var(--text-light); }
        .footer a { color: var(--info); text-decoration: none; }
        @media (max-width: 480px) { .stats-panel { grid-template-columns: repeat(3, 1fr); } .header h1 { font-size: 1.2rem; } }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #bdc3c7; border-radius: 3px; }
        """

        # 构建完整HTML
        html_parts = [
            '<!DOCTYPE html>',
            '<html lang="zh-CN">',
            '<head>',
            '    <meta charset="UTF-8">',
            '    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">',
            '    <title>孟加拉商业情报日报 | ' + date_str + '</title>',
            '    <style>' + css + '</style>',
            '</head>',
            '<body>',
            '    <div class="header">',
            '        <h1>孟加拉商业情报日报 <span class="badge-live">LIVE</span></h1>',
            '        <div class="subtitle">服务中国政策制定者 · 智库学者 · 跨境电商从业者</div>',
            '        <div class="date">' + date_str + ' | 共采集 ' + str(stats['total']) + ' 条情报 | 置信度 ' + str(int(stats.get('avg_confidence', 0) * 100)) + '%</div>',
            '    </div>',
            '    <div class="container">',
            stats_panel,
            risk_section,
            policy_section,
            positive_section,
            '        <div style="margin: 20px 0; text-align: center; font-size: 0.85rem; color: var(--text-light);">',
            '            —— 分产业详细动态 ——',
            '        </div>',
            industry_sections,
            '        <div class="footer">',
            '            <p>孟加拉商业情报日报系统 | 自动生成于 ' + datetime.now().strftime("%Y-%m-%d %H:%M") + '</p>',
            '            <p>数据来源: 50+孟加拉及国际媒体RSS | AI分析模型: GPT-4o-mini / DeepSeek</p>',
            '            <p>本站仅供研究参考，不构成投资建议</p>',
            '        </div>',
            '    </div>',
            '</body>',
            '</html>'
        ]

        return "\n".join(html_parts)

    def _build_section(self, title, section_class, items, max_items=10, empty_msg="暂无数据"):
        """构建区域HTML"""
        if not items:
            return '<div class="section ' + section_class + '"><div class="section-header">' + title + '</div><div class="section-content"><div class="empty-msg">' + empty_msg + '</div></div></div>'

        cards = ""
        for item in items[:max_items]:
            cards += self._build_card(item)

        return '<div class="section ' + section_class + '"><div class="section-header">' + title + ' (' + str(len(items[:max_items])) + ')</div><div class="section-content">' + cards + '</div></div>'

    def _build_industry_section(self, ind_id, ind_name, ind_color, items):
        """构建产业分区HTML"""
        cards = ""
        for item in items[:5]:
            cards += self._build_card(item)

        return '<div class="section industry-section"><div class="section-header" style="border-left-color: ' + ind_color + ';"><span style="color: ' + ind_color + ';">●</span> ' + ind_name + ' (' + str(len(items)) + ')</div><div class="section-content">' + cards + '</div></div>'

    def _build_card(self, item):
        """构建单条情报卡片"""
        original = item.get("original", {})
        title = original.get("title", "未知标题")
        link = original.get("link", "#")
        source = original.get("source_name", "未知来源")
        pub_date = original.get("published", "")[:10]

        summary = item.get("chinese_summary", "")
        impact = item.get("impact", "neutral")
        importance = item.get("importance", "low")
        risk_level = item.get("risk_level", "none")
        industries = item.get("industries", ["others"])
        intel_type = item.get("intelligence_type", "general")
        entities = item.get("entities", {})
        evidence = item.get("evidence", [])
        confidence = item.get("confidence", 0)

        impact_badge, _ = self._get_impact_badge(impact)
        importance_badge = self._get_importance_badge(importance)
        risk_badge = self._get_risk_badge(risk_level)

        # 产业标签
        industry_badges = ""
        for ind in industries[:2]:
            ind_name = self._get_industry_name(ind)
            industry_badges += '<span class="badge badge-industry">' + ind_name + '</span>'

        type_name = self._get_type_name(intel_type)
        type_badge = '<span class="badge badge-type">' + type_name + '</span>'

        # 中国相关标记
        china_badge = ""
        if any(kw in summary.lower() for kw in ["中国", "中方", "北京", "上海", "深圳", "一带一路", "bri", "china", "chinese"]):
            china_badge = '<span class="badge badge-china">涉华</span>'

        # 实体标签
        entity_html = ""
        all_entities = []
        for key in ["companies", "organizations", "people", "projects", "amounts", "locations"]:
            all_entities.extend(entities.get(key, [])[:3])
        if all_entities:
            entity_html = '<div class="card-entities">'
            for e in all_entities[:6]:
                entity_html += '<span class="entity-tag">' + str(e) + '</span>'
            entity_html += '</div>'

        # 证据
        evidence_html = ""
        if evidence:
            evidence_html = '<div class="card-evidence">依据: ' + "; ".join(evidence[:2]) + '</div>'

        return '<div class="intel-card"><div class="card-header"><div class="card-title">' + title + '</div><div class="card-badges">' + impact_badge + importance_badge + risk_badge + china_badge + '</div></div><div class="card-summary">' + summary + '</div>' + entity_html + evidence_html + '<div class="card-meta"><div class="card-meta-left"><span class="card-source">' + source + '</span><span>' + pub_date + '</span>' + industry_badges + type_badge + '<span style="color: #95a5a6;">置信度 ' + str(int(confidence * 100)) + '%</span></div><a href="' + link + '" target="_blank" class="card-link">原文 →</a></div></div>'


if __name__ == "__main__":
    gen = ReportGenerator()
    test_analyses = [
        {
            "industries": ["garment"],
            "intelligence_type": "market",
            "entities": {"companies": ["BGMEA"], "amounts": ["$28.4B"]},
            "chinese_summary": "孟加拉国成衣出口连续6个月负增长，主要受欧盟市场需求下滑影响。中国企业在孟投资纺织业面临订单减少风险。",
            "impact": "negative",
            "impact_reason": "出口下滑影响产业信心",
            "importance": "high",
            "risk_level": "medium",
            "risk_tags": ["出口下滑", "需求疲软"],
            "evidence": ["连续6个月负增长", "欧盟订单减少"],
            "confidence": 0.88,
            "original": {"title": "RMG exports fall for 6th month", "link": "#", "source_name": "The Daily Star", "published": "2026-05-29"}
        }
    ]
    test_stats = {"total": 1, "risk_count": 1, "policy_count": 0, "by_impact": {"positive": 0, "neutral": 0, "negative": 1}, "china_related": 1, "avg_confidence": 0.88}
    gen.generate_html(test_analyses, test_stats, output_dir="test_docs")
